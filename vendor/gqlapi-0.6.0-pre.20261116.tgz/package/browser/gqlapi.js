/*! gqlapi@0.5.1 */
var GraphApi =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.getScalarTypeFormat = exports.getScalarType = void 0;
const scalarMap = {
    Int: 'integer',
    Float: 'number',
    String: 'string',
    Boolean: 'boolean',
};
const getScalarType = (gqlType) => {
    return scalarMap[gqlType.name] || "string";
};
exports.getScalarType = getScalarType;
const getScalarTypeFormat = (gqlType) => {
    switch (gqlType.name) {
        case 'Int':
        case 'String':
        case 'Boolean':
            return '';
        default:
            return gqlType.name;
    }
};
exports.getScalarTypeFormat = getScalarTypeFormat;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2V0U2NhbGFyVHlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9nZXRTY2FsYXJUeXBlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUdBLE1BQU0sU0FBUyxHQUF1QztJQUNwRCxHQUFHLEVBQUUsU0FBUztJQUNkLEtBQUssRUFBRSxRQUFRO0lBQ2YsTUFBTSxFQUFFLFFBQVE7SUFDaEIsT0FBTyxFQUFFLFNBQVM7Q0FDVixDQUFBO0FBRUgsTUFBTSxhQUFhLEdBQUcsQ0FBQyxPQUFvRCxFQUFzQixFQUFFO0lBQ3hHLE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxRQUFRLENBQUE7QUFDNUMsQ0FBQyxDQUFBO0FBRlksUUFBQSxhQUFhLGlCQUV6QjtBQUVNLE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxPQUFvRCxFQUFzQixFQUFFO0lBQzlHLFFBQVEsT0FBTyxDQUFDLElBQUksRUFBRTtRQUNwQixLQUFLLEtBQUssQ0FBQztRQUNYLEtBQUssUUFBUSxDQUFDO1FBQ2QsS0FBSyxTQUFTO1lBQ1osT0FBTyxFQUFFLENBQUE7UUFDWDtZQUNFLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQTtLQUN0QjtBQUNILENBQUMsQ0FBQTtBQVRZLFFBQUEsbUJBQW1CLHVCQVMvQiJ9

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = __webpack_require__(2);
tslib_1.__exportStar(__webpack_require__(3), exports);
tslib_1.__exportStar(__webpack_require__(4), exports);
tslib_1.__exportStar(__webpack_require__(5), exports);
tslib_1.__exportStar(__webpack_require__(6), exports);
tslib_1.__exportStar(__webpack_require__(7), exports);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQTBCO0FBQzFCLHdEQUE2QjtBQUM3Qiw0REFBaUM7QUFDakMsbUVBQXdDO0FBQ3hDLHdEQUE2QiJ9

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__createBinding", function() { return __createBinding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function() { return __classPrivateFieldGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function() { return __classPrivateFieldSet; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __createBinding(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}

function __exportStar(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, privateMap) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return privateMap.get(receiver);
}

function __classPrivateFieldSet(receiver, privateMap, value) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
    }
    privateMap.set(receiver, value);
    return value;
}


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhhcGkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvZ3JhcGhhcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiJ9

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhTY2hlbWEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvZ3JhcGhTY2hlbWEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiJ9

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.buildFromSchema = void 0;
const getScalarType_1 = __webpack_require__(0);
const DEFAULT_DEPRECATION_REASON = 'No longer supported';
const components = {
    ScalarTypeDefinition: "scalars",
    ObjectTypeDefinition: "objects",
    InterfaceTypeDefinition: "interfaces",
    InputObjectTypeDefinition: "inputObjects",
    DirectiveDefinition: "directives",
    UnionTypeDefinition: "unions",
    EnumTypeDefinition: "enums"
};
// workaround to avoid graphql dependency
const isGraphQLType = (gqlType, typeName) => {
    const printName = Object.prototype.toString.call(gqlType);
    return printName === `[object ${typeName}]`;
};
const isNonNullType = (gqlType) => {
    // return gqlType instanceof GraphQLNonNull
    return isGraphQLType(gqlType, "GraphQLNonNull");
};
const isListType = (gqlType) => {
    // return gqlType instanceof GraphQLList
    return isGraphQLType(gqlType, "GraphQLList");
};
const isScalarType = (gqlType) => {
    // return gqlType instanceOf GraphQLScalarType
    return isGraphQLType(gqlType, "GraphQLScalarType");
};
const getTypeKind = (gqlType) => {
    return isScalarType(gqlType) || !gqlType.astNode ? "ScalarTypeDefinition" : gqlType.astNode.kind;
};
const componentRef = (kind, name) => {
    return `#/components/${components[kind]}/${name}`;
};
const transformType2Ref = (gqlType, options, nonNullable = false) => {
    if (isNonNullType(gqlType)) {
        return transformType2Ref(gqlType.ofType, options, true);
    }
    else if (isListType(gqlType)) {
        return Object.assign({ type: "array", items: transformType2Ref(gqlType.ofType, options) }, (nonNullable) ? {} : { nullable: true });
    }
    else if (isScalarType(gqlType)) {
        const format = (0, getScalarType_1.getScalarTypeFormat)(gqlType);
        return Object.assign(Object.assign({ type: (0, getScalarType_1.getScalarType)(gqlType) }, format ? { format } : {}), (nonNullable) ? {} : { nullable: true });
    }
    else {
        return Object.assign({ $ref: componentRef(getTypeKind(gqlType), gqlType.name) }, (nonNullable) ? {} : { nullable: true });
    }
};
const transfromField = (field, options) => {
    return Object.assign(Object.assign({}, transformBaseType(field)), field.args.length ? { args: transformArgs(field.args, options) } : {});
};
const transformOperations = (fields, options) => {
    const operations = {};
    for (const [name, field] of Object.entries(fields)) {
        operations[name] = Object.assign(Object.assign({}, transfromField(field, options)), transformType2Ref(field.type, options));
    }
    return operations;
};
const directiveNodeReducer = (result, value) => {
    if (value.name.value !== 'deprecated') {
        result[value.name.value] = transformDirectiveNode(value);
    }
    return result;
};
const transfromDirectiveArgValue = (arg) => {
    switch (arg.kind) {
        case "IntValue":
        case "FloatValue":
        case "BooleanValue":
        case "EnumValue":
        case "StringValue":
            return arg.value;
        case "NullValue":
            return null;
        case "ListValue":
            return arg.values.map(transfromDirectiveArgValue);
        case "ObjectValue":
            return arg.fields.reduce((result, item) => {
                result[item.name.value] = transfromDirectiveArgValue(item.value);
                return result;
            }, {});
    }
};
const transformDirectiveNode = (node) => {
    var _a;
    const meta = (_a = node.arguments) === null || _a === void 0 ? void 0 : _a.reduce((args, arg) => {
        args[arg.name.value] = transfromDirectiveArgValue(arg.value);
        return args;
    }, {});
    return Object.assign({ $ref: componentRef("DirectiveDefinition", node.name.value) }, meta && Object.keys(meta).length ? { meta } : {});
};
const transformBaseType = (baseType) => {
    var _a, _b;
    const directives = ((_b = (_a = baseType.astNode) === null || _a === void 0 ? void 0 : _a.directives) !== null && _b !== void 0 ? _b : []).reduce(directiveNodeReducer, {});
    const reason = 'deprecationReason' in baseType ? baseType.deprecationReason : '';
    return Object.assign(Object.assign(Object.assign({}, reason ? { deprecated: reason !== DEFAULT_DEPRECATION_REASON ? { reason } : true } : {}), baseType.description ? { description: baseType.description } : {}), Object.keys(directives).length ? { directives } : {});
};
const transformNamedType = (baseType) => {
    return Object.assign({ title: baseType.name }, transformBaseType(baseType));
};
const transformScalarType = (scalarType, options) => {
    return Object.assign(Object.assign(Object.assign({}, transformNamedType(scalarType)), { type: (0, getScalarType_1.getScalarType)(scalarType) }), scalarType.specifiedByURL ? { specifiedByURL: scalarType.specifiedByURL } : {});
};
const transformObjectType = (objectType, options) => {
    const properties = {};
    const fields = objectType.getFields();
    const required = [];
    const interfaces = objectType.getInterfaces().map((item) => ({ $ref: componentRef(item.astNode.kind, item.name) }));
    for (const [name, field] of Object.entries(fields)) {
        if (isNonNullType(field.type)) {
            required.push(field.name);
        }
        properties[name] = Object.assign(Object.assign(Object.assign({}, transformBaseType(field)), transformType2Ref(field.type, options, true)), field.args.length ? { args: transformArgs(field.args, options) } : {});
    }
    return Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, transformNamedType(objectType)), { type: "object" }), required.length ? { required } : {}), { properties }), interfaces.length ? { interfaces } : {});
};
const transfromUnionType = (unionType, options) => {
    return Object.assign(Object.assign({}, transformNamedType(unionType)), { oneOf: unionType.getTypes().map((item) => transformType2Ref(item, options, true)) });
};
const transformEnumType = (enumType, options) => {
    const enumKeys = [];
    const enumValues = enumType.getValues().reduce((res, { deprecationReason: reason, description, value }) => {
        enumKeys.push(value);
        if (reason || description) {
            res[value] = Object.assign(Object.assign({}, reason ? { deprecated: reason === DEFAULT_DEPRECATION_REASON ? true : { reason } } : {}), description ? { description } : {});
        }
        return res;
    }, {});
    return Object.assign(Object.assign(Object.assign({}, transformNamedType(enumType)), { type: "string", enum: enumKeys }), Object.keys(enumValues).length ? { values: enumValues } : {});
};
const transformInputObjectType = (inputObjectType, options) => {
    const properties = {};
    const fields = inputObjectType.getFields();
    const required = [];
    for (const [name, field] of Object.entries(fields)) {
        isNonNullType(field.type) && required.push(name);
        properties[name] = Object.assign(Object.assign(Object.assign({}, transformNamedType(field)), transformType2Ref(field.type, options, true)), field.defaultValue !== undefined ? { default: field.defaultValue } : {});
    }
    return Object.assign(Object.assign(Object.assign(Object.assign({}, transformNamedType(inputObjectType)), { title: inputObjectType.name, type: "object" }), required.length ? { required } : {}), { properties });
};
const transformType = (gqlType, options) => {
    const kind = getTypeKind(gqlType);
    switch (kind) {
        case "ScalarTypeDefinition":
            return transformScalarType(gqlType, options);
        case "ObjectTypeDefinition":
            return transformObjectType(gqlType, options);
        case "InterfaceTypeDefinition":
            return transformObjectType(gqlType, options);
        case "InputObjectTypeDefinition":
            return transformInputObjectType(gqlType, options);
        case "UnionTypeDefinition":
            return transfromUnionType(gqlType, options);
        case "EnumTypeDefinition":
            return transformEnumType(gqlType, options);
        default:
            throw new Error("Unsupported type");
    }
};
const transformTypes = (gqlTypeMap, options, skip = []) => {
    const result = {};
    for (const [name, gqlType] of Object.entries(gqlTypeMap)) {
        if (['String', 'Int', 'Float', 'Boolean', 'ID'].includes(name)) {
            continue;
        }
        if (name.startsWith("__") || skip.includes(name)) {
            continue;
        }
        const kind = getTypeKind(gqlType);
        result[components[kind]] = result[components[kind]] || {};
        result[components[kind]][name] = transformType(gqlType, options);
    }
    return result;
};
const transformArgs = (args, options) => {
    const properties = {};
    const required = [];
    for (const arg of args) {
        if (isNonNullType(arg.type)) {
            required.push(arg.name);
        }
        properties[arg.name] = Object.assign(Object.assign(Object.assign({}, transformType2Ref(arg.type, options, true)), transformBaseType(arg)), arg.defaultValue !== undefined ? { default: arg.defaultValue } : {});
    }
    return Object.assign(Object.assign({ type: "object" }, required.length ? { required } : {}), { properties });
};
const directiveSchemaReducer = (options) => (result, directive) => {
    if (!['specifiedBy', 'deprecated'].includes(directive.name)) {
        result[directive.name] = transformDirectiveSchema(directive, options);
    }
    return result;
};
const transformDirectiveSchema = (directive, options) => {
    return Object.assign(Object.assign(Object.assign(Object.assign({ title: directive.name }, directive.description ? { description: directive.description } : {}), { locations: [...directive.locations] }), directive.args.length ? { args: transformArgs(directive.args, options) } : {}), { repeatable: directive.isRepeatable });
};
const buildFromSchema = (schema, options = {}) => {
    const qType = schema.getQueryType();
    const mType = schema.getMutationType();
    const sType = schema.getSubscriptionType();
    // skip Query, Mutation and Subscription in componets
    const skip = [qType, mType, sType].reduce((r, i) => i ? [...r, i.name] : r, []);
    return Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({ graphapi: "0.1.2" }, schema.description ? { description: schema.description } : {}), qType ? { queries: transformOperations(qType.getFields(), options) } : {}), mType ? { mutations: transformOperations(mType.getFields(), options) } : {}), sType ? { subscriptions: transformOperations(sType.getFields(), options) } : {}), { components: Object.assign(Object.assign({}, transformTypes(schema.getTypeMap(), options, skip)), { directives: schema.getDirectives().reduce(directiveSchemaReducer(options), {}) }) });
};
exports.buildFromSchema = buildFromSchema;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVpbGRGcm9tU2NoZW1hLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2J1aWxkRnJvbVNjaGVtYS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFhQSxtREFBb0U7QUFHcEUsTUFBTSwwQkFBMEIsR0FBRyxxQkFBcUIsQ0FBQTtBQUV4RCxNQUFNLFVBQVUsR0FBRztJQUNqQixvQkFBb0IsRUFBRSxTQUFTO0lBQy9CLG9CQUFvQixFQUFFLFNBQVM7SUFDL0IsdUJBQXVCLEVBQUUsWUFBWTtJQUNyQyx5QkFBeUIsRUFBRSxjQUFjO0lBQ3pDLG1CQUFtQixFQUFFLFlBQVk7SUFDakMsbUJBQW1CLEVBQUUsUUFBUTtJQUM3QixrQkFBa0IsRUFBRSxPQUFPO0NBQ25CLENBQUE7QUFJVix5Q0FBeUM7QUFDekMsTUFBTSxhQUFhLEdBQUcsQ0FBQyxPQUE0QixFQUFFLFFBQWdCLEVBQVcsRUFBRTtJQUNoRixNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDekQsT0FBTyxTQUFTLEtBQUssV0FBVyxRQUFRLEdBQUcsQ0FBQTtBQUM3QyxDQUFDLENBQUE7QUFFRCxNQUFNLGFBQWEsR0FBRyxDQUFDLE9BQTRCLEVBQWtDLEVBQUU7SUFDckYsMkNBQTJDO0lBQzNDLE9BQU8sYUFBYSxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFBO0FBQ2pELENBQUMsQ0FBQTtBQUVELE1BQU0sVUFBVSxHQUFHLENBQUMsT0FBNEIsRUFBK0IsRUFBRTtJQUMvRSx3Q0FBd0M7SUFDeEMsT0FBTyxhQUFhLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFBO0FBQzlDLENBQUMsQ0FBQTtBQUVELE1BQU0sWUFBWSxHQUFHLENBQUMsT0FBeUIsRUFBZ0MsRUFBRTtJQUMvRSw4Q0FBOEM7SUFDOUMsT0FBTyxhQUFhLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLENBQUE7QUFDcEQsQ0FBQyxDQUFBO0FBRUQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxPQUF5QixFQUFrQixFQUFFO0lBQ2hFLE9BQU8sWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFRLENBQUMsSUFBSSxDQUFBO0FBQ25HLENBQUMsQ0FBQTtBQUVELE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBb0IsRUFBRSxJQUFZLEVBQVUsRUFBRTtJQUNsRSxPQUFPLGdCQUFnQixVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUE7QUFDbkQsQ0FBQyxDQUFBO0FBRUQsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLE9BQTRCLEVBQUUsT0FBcUIsRUFBRSxXQUFXLEdBQUcsS0FBSyxFQUFlLEVBQUU7SUFDbEgsSUFBSSxhQUFhLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDMUIsT0FBTyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQTtLQUN4RDtTQUFNLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQzlCLHVCQUNFLElBQUksRUFBRyxPQUFPLEVBQ2QsS0FBSyxFQUFFLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLElBQzlDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEVBQzNDO0tBQ0Y7U0FBTSxJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBRTtRQUNoQyxNQUFNLE1BQU0sR0FBRyxJQUFBLG1DQUFtQixFQUFDLE9BQU8sQ0FBQyxDQUFBO1FBQzNDLHFDQUNFLElBQUksRUFBRSxJQUFBLDZCQUFhLEVBQUMsT0FBTyxDQUFDLElBQ3pCLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUN4QixDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxFQUMzQztLQUNGO1NBQU07UUFDTCx1QkFDRSxJQUFJLEVBQUUsWUFBWSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQ25ELENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEVBQzNDO0tBQ0Y7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLGNBQWMsR0FBRyxDQUFDLEtBQTZCLEVBQUUsT0FBcUIsRUFBZSxFQUFFO0lBQzNGLHVDQUNLLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUN4QixLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUN6RTtBQUNILENBQUMsQ0FBQTtBQUVELE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxNQUE4QyxFQUFFLE9BQXFCLEVBQStCLEVBQUU7SUFDakksTUFBTSxVQUFVLEdBQWdDLEVBQUUsQ0FBQTtJQUNsRCxLQUFLLE1BQU0sQ0FBRSxJQUFJLEVBQUUsS0FBSyxDQUFFLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNwRCxVQUFVLENBQUMsSUFBSSxDQUFDLG1DQUNYLGNBQWMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEdBQzlCLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQzFDLENBQUE7S0FDRjtJQUNELE9BQU8sVUFBVSxDQUFBO0FBQ25CLENBQUMsQ0FBQTtBQUVELE1BQU0sb0JBQW9CLEdBQUcsQ0FBQyxNQUF5QyxFQUFFLEtBQXlCLEVBQUUsRUFBRTtJQUNwRyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLFlBQVksRUFBRTtRQUNyQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsQ0FBQTtLQUN6RDtJQUNELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQyxDQUFBO0FBRUQsTUFBTSwwQkFBMEIsR0FBRyxDQUFDLEdBQW1CLEVBQU8sRUFBRTtJQUM5RCxRQUFRLEdBQUcsQ0FBQyxJQUFJLEVBQUU7UUFDaEIsS0FBSyxVQUFVLENBQUM7UUFBQyxLQUFLLFlBQVksQ0FBQztRQUFDLEtBQUssY0FBYyxDQUFDO1FBQUMsS0FBSyxXQUFXLENBQUM7UUFBQyxLQUFLLGFBQWE7WUFDM0YsT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFBO1FBQ2xCLEtBQUssV0FBVztZQUNkLE9BQU8sSUFBSSxDQUFBO1FBQ2IsS0FBSyxXQUFXO1lBQ2QsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFBO1FBQ25ELEtBQUssYUFBYTtZQUNoQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFO2dCQUN4QyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7Z0JBQ2hFLE9BQU8sTUFBTSxDQUFBO1lBQ2YsQ0FBQyxFQUFFLEVBQVMsQ0FBQyxDQUFBO0tBQ2hCO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSxzQkFBc0IsR0FBRyxDQUFDLElBQXdCLEVBQU8sRUFBRTs7SUFDL0QsTUFBTSxJQUFJLEdBQUcsTUFBQSxJQUFJLENBQUMsU0FBUywwQ0FBRSxNQUFNLENBQUMsQ0FBQyxJQUF5QixFQUFFLEdBQUcsRUFBRSxFQUFFO1FBQ3JFLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtRQUM1RCxPQUFPLElBQUksQ0FBQTtJQUNiLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUNOLHVCQUNFLElBQUksRUFBRSxZQUFZLENBQUMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFDdkQsSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQ3BEO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLFFBQTBGLEVBQWUsRUFBRTs7SUFDcEksTUFBTSxVQUFVLEdBQUcsQ0FBQyxNQUFBLE1BQUEsUUFBUSxDQUFDLE9BQU8sMENBQUUsVUFBVSxtQ0FBSSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsRUFBRSxDQUFDLENBQUE7SUFDeEYsTUFBTSxNQUFNLEdBQUcsbUJBQW1CLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtJQUNoRixxREFDSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sS0FBSywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FDdkYsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQ2pFLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQ3hEO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLFFBQTBGLEVBQWUsRUFBRTtJQUNySSx1QkFDRSxLQUFLLEVBQUUsUUFBUSxDQUFDLElBQUksSUFDakIsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEVBQy9CO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLFVBQTZCLEVBQUUsT0FBcUIsRUFBa0IsRUFBRTtJQUNuRyxxREFDSyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsS0FDakMsSUFBSSxFQUFFLElBQUEsNkJBQWEsRUFBQyxVQUFVLENBQUMsS0FDNUIsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsVUFBVSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQ2xGO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLFVBQW9ELEVBQUUsT0FBcUIsRUFBa0IsRUFBRTtJQUMxSCxNQUFNLFVBQVUsR0FBZ0MsRUFBRSxDQUFBO0lBQ2xELE1BQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxTQUFTLEVBQUUsQ0FBQTtJQUNyQyxNQUFNLFFBQVEsR0FBYSxFQUFFLENBQUE7SUFDN0IsTUFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO0lBRXBILEtBQUssTUFBTSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ2xELElBQUksYUFBYSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM3QixRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtTQUMxQjtRQUVELFVBQVUsQ0FBQyxJQUFJLENBQUMsaURBQ1gsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEdBQ3hCLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxHQUU1QyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUN6RSxDQUFBO0tBQ0Y7SUFFRCxpRkFDSyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsS0FDakMsSUFBSSxFQUFFLFFBQVEsS0FDWCxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQ3RDLFVBQVUsS0FDUCxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQzNDO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLFNBQTJCLEVBQUUsT0FBcUIsRUFBaUIsRUFBRTtJQUMvRix1Q0FDSyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsS0FDaEMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFDbEY7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLGlCQUFpQixHQUFHLENBQUMsUUFBeUIsRUFBRSxPQUFxQixFQUFnQixFQUFFO0lBQzNGLE1BQU0sUUFBUSxHQUFhLEVBQUUsQ0FBQTtJQUM3QixNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFO1FBQ3hHLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDcEIsSUFBSSxNQUFNLElBQUksV0FBVyxFQUFFO1lBQ3pCLEdBQUcsQ0FBQyxLQUFLLENBQUMsbUNBQ0wsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEtBQUssMEJBQTBCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQSxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQ3JGLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUN0QyxDQUFBO1NBQ0Y7UUFDRCxPQUFPLEdBQUcsQ0FBQTtJQUNaLENBQUMsRUFBRSxFQUFvQyxDQUFDLENBQUE7SUFFeEMscURBQ0ssa0JBQWtCLENBQUMsUUFBUSxDQUFDLEtBQy9CLElBQUksRUFBRSxRQUFRLEVBQ2QsSUFBSSxFQUFFLFFBQVEsS0FDWCxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFDaEU7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLHdCQUF3QixHQUFHLENBQUMsZUFBdUMsRUFBRSxPQUFxQixFQUF1QixFQUFFO0lBQ3ZILE1BQU0sVUFBVSxHQUFnQyxFQUFFLENBQUE7SUFDbEQsTUFBTSxNQUFNLEdBQUcsZUFBZSxDQUFDLFNBQVMsRUFBRSxDQUFBO0lBQzFDLE1BQU0sUUFBUSxHQUFhLEVBQUUsQ0FBQTtJQUU3QixLQUFLLE1BQU0sQ0FBRSxJQUFJLEVBQUUsS0FBSyxDQUFFLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNwRCxhQUFhLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDaEQsVUFBVSxDQUFDLElBQUksQ0FBQyxpREFDWCxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsR0FDekIsaUJBQWlCLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQzVDLEtBQUssQ0FBQyxZQUFZLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FDM0UsQ0FBQTtLQUNGO0lBRUQsbUVBQ0ssa0JBQWtCLENBQUMsZUFBZSxDQUFDLEtBQ3RDLEtBQUssRUFBRSxlQUFlLENBQUMsSUFBSSxFQUMzQixJQUFJLEVBQUUsUUFBUSxLQUNYLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FDdEMsVUFBVSxJQUNYO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSxhQUFhLEdBQUcsQ0FBQyxPQUF5QixFQUFFLE9BQXFCLEVBQWUsRUFBRTtJQUN0RixNQUFNLElBQUksR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDakMsUUFBUSxJQUFJLEVBQUU7UUFDWixLQUFLLHNCQUFzQjtZQUN6QixPQUFPLG1CQUFtQixDQUFDLE9BQTRCLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFDbkUsS0FBSyxzQkFBc0I7WUFDekIsT0FBTyxtQkFBbUIsQ0FBQyxPQUE0QixFQUFFLE9BQU8sQ0FBQyxDQUFBO1FBQ25FLEtBQUsseUJBQXlCO1lBQzVCLE9BQU8sbUJBQW1CLENBQUMsT0FBK0IsRUFBRSxPQUFPLENBQUMsQ0FBQTtRQUN0RSxLQUFLLDJCQUEyQjtZQUM5QixPQUFPLHdCQUF3QixDQUFDLE9BQWlDLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFDN0UsS0FBSyxxQkFBcUI7WUFDeEIsT0FBTyxrQkFBa0IsQ0FBQyxPQUEyQixFQUFFLE9BQU8sQ0FBQyxDQUFBO1FBQ2pFLEtBQUssb0JBQW9CO1lBQ3ZCLE9BQU8saUJBQWlCLENBQUMsT0FBMEIsRUFBRSxPQUFPLENBQUMsQ0FBQTtRQUMvRDtZQUNFLE1BQU0sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQTtLQUN0QztBQUNILENBQUMsQ0FBQTtBQUVELE1BQU0sY0FBYyxHQUFHLENBQUMsVUFBNEMsRUFBRSxPQUFxQixFQUFFLE9BQWlCLEVBQUUsRUFBK0MsRUFBRTtJQUMvSixNQUFNLE1BQU0sR0FBZ0QsRUFBRSxDQUFBO0lBQzlELEtBQUssTUFBTSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQ3hELElBQUksQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQUUsU0FBUTtTQUFFO1FBQzVFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQUUsU0FBUTtTQUFFO1FBQzlELE1BQU0sSUFBSSxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUNqQyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtRQUN6RCxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsYUFBYSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQTtLQUNqRTtJQUNELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQyxDQUFBO0FBRUQsTUFBTSxhQUFhLEdBQUcsQ0FBQyxJQUFvQyxFQUFFLE9BQXFCLEVBQWtCLEVBQUU7SUFDcEcsTUFBTSxVQUFVLEdBQWdDLEVBQUUsQ0FBQTtJQUNsRCxNQUFNLFFBQVEsR0FBYSxFQUFFLENBQUE7SUFFN0IsS0FBSyxNQUFNLEdBQUcsSUFBSSxJQUFJLEVBQUU7UUFDdEIsSUFBSSxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzNCLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO1NBQ3hCO1FBRUQsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaURBQ2YsaUJBQWlCLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQzFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUV0QixHQUFHLENBQUMsWUFBWSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQ3ZFLENBQUE7S0FDRjtJQUVELHFDQUNFLElBQUksRUFBRSxRQUFRLElBQ1gsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUN0QyxVQUFVLElBQ1g7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLHNCQUFzQixHQUFHLENBQUMsT0FBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxNQUFtRCxFQUFFLFNBQTJCLEVBQUUsRUFBRTtJQUM3SSxJQUFJLENBQUMsQ0FBQyxhQUFhLEVBQUUsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtRQUMzRCxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLHdCQUF3QixDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQTtLQUN0RTtJQUNELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQyxDQUFBO0FBRUQsTUFBTSx3QkFBd0IsR0FBRyxDQUFDLFNBQTJCLEVBQUUsT0FBcUIsRUFBK0IsRUFBRTtJQUNuSCxpRUFDRSxLQUFLLEVBQUUsU0FBUyxDQUFDLElBQUksSUFDbEIsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQ3RFLFNBQVMsRUFBRSxDQUFFLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBRSxLQUNsQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUNoRixVQUFVLEVBQUUsU0FBUyxDQUFDLFlBQVksSUFDbkM7QUFDSCxDQUFDLENBQUE7QUFLTSxNQUFNLGVBQWUsR0FBRyxDQUFDLE1BQXFCLEVBQUUsVUFBd0IsRUFBRSxFQUFrQixFQUFFO0lBQ25HLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQTtJQUNuQyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsZUFBZSxFQUFFLENBQUE7SUFDdEMsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLG1CQUFtQixFQUFFLENBQUE7SUFFMUMscURBQXFEO0lBQ3JELE1BQU0sSUFBSSxHQUFHLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFXLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUE7SUFFekYsK0VBQ0UsUUFBUSxFQUFFLE9BQU8sSUFDZCxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FDN0QsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUN6RSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxFQUFFLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQzNFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxhQUFhLEVBQUUsbUJBQW1CLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FDbEYsVUFBVSxrQ0FDTCxjQUFjLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FDckQsVUFBVSxFQUFFLE1BQU0sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxDQUFDLE9BRWpGO0FBQ0gsQ0FBQyxDQUFBO0FBbkJZLFFBQUEsZUFBZSxtQkFtQjNCIn0=

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.buildFromIntrospection = void 0;
const getScalarType_1 = __webpack_require__(0);
const DEFAULT_DEPRECATION_REASON = 'No longer supported';
const components = {
    SCALAR: "scalars",
    OBJECT: "objects",
    INTERFACE: "interfaces",
    INPUT_OBJECT: "inputObjects",
    DERICTIVE: "directives",
    UNION: "unions",
    ENUM: "enums"
};
const componentRef = (kind, name) => {
    return `#/components/${components[kind]}/${name}`;
};
const transformType2Ref = (gqlType, options, nonNullable = false) => {
    if (gqlType.kind === "NON_NULL") {
        return transformType2Ref(gqlType.ofType, options, true);
    }
    else if (gqlType.kind === "LIST") {
        return Object.assign({ type: "array", items: transformType2Ref(gqlType.ofType, options) }, (nonNullable) ? {} : { nullable: true });
    }
    else if (gqlType.kind === "SCALAR") {
        const format = (0, getScalarType_1.getScalarTypeFormat)(gqlType);
        return Object.assign(Object.assign({ type: (0, getScalarType_1.getScalarType)(gqlType) }, format ? { format } : {}), (nonNullable) ? {} : { nullable: true });
    }
    else {
        return Object.assign({ $ref: componentRef(gqlType.kind, gqlType.name) }, (nonNullable) ? {} : { nullable: true });
    }
};
const transfromField = (field, options) => {
    return Object.assign(Object.assign({}, transformNamedType(field)), field.args.length ? { args: transformArgs(field.args, options) } : {});
};
const transformOperations = (fields, options) => {
    const operations = {};
    for (const field of fields) {
        operations[field.name] = Object.assign(Object.assign({}, transfromField(field, options)), transformType2Ref(field.type, options));
    }
    return operations;
};
const transformBaseType = (baseType) => {
    const isDeprecated = "isDeprecated" in baseType ? baseType.isDeprecated : false;
    const reason = "deprecationReason" in baseType ? baseType.deprecationReason : '';
    return Object.assign(Object.assign({}, baseType.description ? { description: baseType.description } : {}), isDeprecated ? {
        deprecated: reason && reason !== DEFAULT_DEPRECATION_REASON ? { reason } : true
    } : {});
};
const transformNamedType = (baseType) => {
    return Object.assign({ title: baseType.name }, transformBaseType(baseType));
};
const transformScalarType = (scalarType, options) => {
    return Object.assign(Object.assign(Object.assign({}, transformNamedType(scalarType)), { type: (0, getScalarType_1.getScalarType)(scalarType) }), scalarType.specifiedByURL ? { specifiedByURL: scalarType.specifiedByURL } : {});
};
const transformObjectType = (objectType, options) => {
    const properties = {};
    const required = [];
    const interfaces = objectType.interfaces.map(({ kind, name }) => ({ $ref: componentRef(kind, name) }));
    for (const field of objectType.fields) {
        if (field.type.kind === "NON_NULL") {
            required.push(field.name);
        }
        properties[field.name] = Object.assign(Object.assign(Object.assign({}, transformBaseType(field)), transformType2Ref(field.type, options, true)), field.args.length ? { args: transformArgs(field.args, options) } : {});
    }
    return Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, transformNamedType(objectType)), { type: "object" }), required.length ? { required } : {}), { properties }), interfaces.length ? { interfaces } : {});
};
const transfromUnionType = (unionType, options) => {
    return Object.assign(Object.assign({}, transformNamedType(unionType)), { oneOf: unionType.possibleTypes.map((item) => transformType2Ref(item, options, true)) });
};
const transformEnumType = (enumType, options) => {
    const enumKeys = [];
    const enumValues = enumType.enumValues.reduce((res, { deprecationReason, description, name }) => {
        enumKeys.push(name);
        if (deprecationReason || description) {
            res[name] = Object.assign(Object.assign({}, deprecationReason ? { deprecationReason } : {}), description ? { description } : {});
        }
        return res;
    }, {});
    return Object.assign(Object.assign(Object.assign({}, transformNamedType(enumType)), { type: "string", enum: enumKeys }), Object.keys(enumValues).length ? { values: enumValues } : {});
};
const transformInputObjectType = (inputObjectType, options) => {
    const properties = {};
    const required = [];
    const fields = inputObjectType.inputFields;
    for (const field of fields) {
        const defaultValue = getDefaultValue(field);
        if (field.type.kind === "NON_NULL") {
            required.push(field.name);
        }
        properties[field.name] = Object.assign(Object.assign(Object.assign({}, transformNamedType(field)), transformType2Ref(field.type, options, true)), defaultValue ? { default: defaultValue } : {});
    }
    return Object.assign(Object.assign(Object.assign(Object.assign({}, transformNamedType(inputObjectType)), { type: "object", title: inputObjectType.name }), required.length ? { required } : {}), { properties });
};
const directiveSchemaReducer = (options) => (result, directive) => {
    if (!['specifiedBy', 'deprecated'].includes(directive.name)) {
        result[directive.name] = transformDirectiveSchema(directive, options);
    }
    return result;
};
const getDefaultValue = (arg) => {
    if (!arg.defaultValue || !("name" in arg.type)) {
        return arg.defaultValue;
    }
    switch (arg.type.name) {
        case 'Int':
        case 'Float':
            return +arg.defaultValue;
        case 'Boolean':
            return arg.defaultValue === "true";
    }
    return arg.defaultValue;
};
const transformArgs = (inputValues, options) => {
    const properties = {};
    const required = [];
    for (const arg of inputValues) {
        const defaultValue = getDefaultValue(arg);
        if (arg.type.kind === "NON_NULL") {
            required.push(arg.name);
        }
        properties[arg.name] = Object.assign(Object.assign(Object.assign({}, transformType2Ref(arg.type, options, true)), transformBaseType(arg)), defaultValue !== null ? { default: defaultValue } : {});
    }
    return Object.assign(Object.assign({ type: "object" }, required.length ? { required } : {}), { properties });
};
const transformDirectiveSchema = (directive, options) => {
    return Object.assign(Object.assign(Object.assign(Object.assign({ title: directive.name }, directive.description ? { description: directive.description } : {}), { locations: [...directive.locations] }), directive.args.length ? { args: transformArgs(directive.args, options) } : {}), { repeatable: !!directive.isRepeatable });
};
const buildFromIntrospection = ({ __schema }, options = {}) => {
    const { queryType, mutationType, subscriptionType, description, types = [], directives = [] } = __schema;
    const getOperationType = (gqlType) => {
        switch (gqlType.name) {
            case queryType.name:
                return "queries";
            case mutationType === null || mutationType === void 0 ? void 0 : mutationType.name:
                return "mutations";
            case subscriptionType === null || subscriptionType === void 0 ? void 0 : subscriptionType.name:
                return "subscriptions";
        }
    };
    const typeReducer = (result, current) => {
        switch (current.name) {
            case queryType.name:
            case mutationType === null || mutationType === void 0 ? void 0 : mutationType.name:
            case subscriptionType === null || subscriptionType === void 0 ? void 0 : subscriptionType.name: {
                const obj = current;
                const prop = getOperationType(current);
                result[prop] = transformOperations(obj.fields, options);
                break;
            }
            default:
                if (current.name.startsWith("__")) {
                    return result;
                }
                switch (current.kind) {
                    case "SCALAR":
                        if (!['String', 'Int', 'Float', 'Boolean', 'ID'].includes(current.name)) {
                            result.components.scalars = Object.assign(Object.assign({}, result.components.scalars), { [current.name]: transformScalarType(current, options) });
                        }
                        break;
                    case "OBJECT":
                        result.components.objects = Object.assign(Object.assign({}, result.components.objects), { [current.name]: transformObjectType(current, options) });
                        break;
                    case "INTERFACE":
                        result.components.interfaces = Object.assign(Object.assign({}, result.components.interfaces), { [current.name]: transformObjectType(current, options) });
                        break;
                    case "INPUT_OBJECT":
                        result.components.inputObjects = Object.assign(Object.assign({}, result.components.inputObjects), { [current.name]: transformInputObjectType(current, options) });
                        break;
                    case "UNION":
                        result.components.unions = Object.assign(Object.assign({}, result.components.unions), { [current.name]: transfromUnionType(current, options) });
                        break;
                    case "ENUM":
                        result.components.enums = Object.assign(Object.assign({}, result.components.enums), { [current.name]: transformEnumType(current, options) });
                        break;
                }
                break;
        }
        return result;
    };
    return types.reduce(typeReducer, Object.assign(Object.assign({ graphapi: "0.1.2" }, description ? { description } : {}), { components: Object.assign({}, directives.length ? { directives: directives.reduce(directiveSchemaReducer(options), {}) } : {}) }));
};
exports.buildFromIntrospection = buildFromIntrospection;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVpbGRGcm9tSW50cm9zcGVjdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9idWlsZEZyb21JbnRyb3NwZWN0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQWFBLG1EQUFvRTtBQUlwRSxNQUFNLDBCQUEwQixHQUFHLHFCQUFxQixDQUFBO0FBRXhELE1BQU0sVUFBVSxHQUFHO0lBQ2pCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLFNBQVMsRUFBRSxZQUFZO0lBQ3ZCLFlBQVksRUFBRSxjQUFjO0lBQzVCLFNBQVMsRUFBRSxZQUFZO0lBQ3ZCLEtBQUssRUFBRSxRQUFRO0lBQ2YsSUFBSSxFQUFFLE9BQU87Q0FDTCxDQUFBO0FBSVYsTUFBTSxZQUFZLEdBQUcsQ0FBQyxJQUFvQixFQUFFLElBQVksRUFBVSxFQUFFO0lBQ2xFLE9BQU8sZ0JBQWdCLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQTtBQUNuRCxDQUFDLENBQUE7QUFFRCxNQUFNLGlCQUFpQixHQUFHLENBQUMsT0FBNkIsRUFBRSxPQUFxQixFQUFFLFdBQVcsR0FBRyxLQUFLLEVBQWUsRUFBRTtJQUNuSCxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUFFO1FBQy9CLE9BQU8saUJBQWlCLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUE7S0FDeEQ7U0FBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFO1FBQ2xDLHVCQUNFLElBQUksRUFBRSxPQUFPLEVBQ2IsS0FBSyxFQUFFLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLElBQzlDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEVBQzNDO0tBQ0Y7U0FBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFO1FBQ3BDLE1BQU0sTUFBTSxHQUFHLElBQUEsbUNBQW1CLEVBQUMsT0FBa0MsQ0FBQyxDQUFBO1FBQ3RFLHFDQUNFLElBQUksRUFBRSxJQUFBLDZCQUFhLEVBQUMsT0FBa0MsQ0FBQyxJQUNwRCxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FDeEIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFDM0M7S0FDRjtTQUFNO1FBQ0wsdUJBQ0UsSUFBSSxFQUFFLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFDM0MsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFDM0M7S0FDRjtBQUVILENBQUMsQ0FBQTtBQUVELE1BQU0sY0FBYyxHQUFHLENBQUMsS0FBeUIsRUFBRSxPQUFxQixFQUFlLEVBQUU7SUFDdkYsdUNBQ0ssa0JBQWtCLENBQUMsS0FBSyxDQUFDLEdBQ3pCLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxhQUFhLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQ3pFO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLE1BQXFDLEVBQUUsT0FBcUIsRUFBK0IsRUFBRTtJQUN4SCxNQUFNLFVBQVUsR0FBZ0MsRUFBRSxDQUFBO0lBQ2xELEtBQUssTUFBTSxLQUFLLElBQUksTUFBTSxFQUFFO1FBQzFCLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLG1DQUNqQixjQUFjLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxHQUM5QixpQkFBaUIsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUMxQyxDQUFBO0tBQ0Y7SUFDRCxPQUFPLFVBQVUsQ0FBQTtBQUNuQixDQUFDLENBQUE7QUFFRCxNQUFNLGlCQUFpQixHQUFHLENBQUMsUUFBbUcsRUFBZSxFQUFFO0lBQzdJLE1BQU0sWUFBWSxHQUFHLGNBQWMsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQTtJQUMvRSxNQUFNLE1BQU0sR0FBRyxtQkFBbUIsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO0lBQ2hGLHVDQUNLLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUNqRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQ2hCLFVBQVUsRUFBRSxNQUFNLElBQUksTUFBTSxLQUFLLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJO0tBQ2hGLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFDUDtBQUNILENBQUMsQ0FBQTtBQUVELE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxRQUEwRSxFQUFlLEVBQUU7SUFDckgsdUJBQ0UsS0FBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLElBQ2pCLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxFQUMvQjtBQUNILENBQUMsQ0FBQTtBQUVELE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxVQUFtQyxFQUFFLE9BQXFCLEVBQWtCLEVBQUU7SUFDekcscURBQ0ssa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQ2pDLElBQUksRUFBRSxJQUFBLDZCQUFhLEVBQUMsVUFBVSxDQUFDLEtBQzVCLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUUsY0FBYyxFQUFFLFVBQVUsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUNsRjtBQUNILENBQUMsQ0FBQTtBQUVELE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxVQUFnRSxFQUFFLE9BQXFCLEVBQWtCLEVBQUU7SUFDdEksTUFBTSxVQUFVLEdBQWdDLEVBQUUsQ0FBQTtJQUNsRCxNQUFNLFFBQVEsR0FBYSxFQUFFLENBQUE7SUFDN0IsTUFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxZQUFZLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFBO0lBRXJHLEtBQUssTUFBTSxLQUFLLElBQUksVUFBVSxDQUFDLE1BQU0sRUFBRTtRQUNyQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFVBQVUsRUFBRTtZQUNsQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtTQUMxQjtRQUVELFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGlEQUNqQixpQkFBaUIsQ0FBQyxLQUFLLENBQUMsR0FDeEIsaUJBQWlCLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQzVDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxhQUFhLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQ3pFLENBQUE7S0FDRjtJQUVELGlGQUNLLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxLQUNqQyxJQUFJLEVBQUUsUUFBUSxLQUNYLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FDdEMsVUFBVSxLQUNQLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFDM0M7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLGtCQUFrQixHQUFHLENBQUMsU0FBaUMsRUFBRSxPQUFxQixFQUFpQixFQUFFO0lBQ3JHLHVDQUNLLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxLQUNoQyxLQUFLLEVBQUUsU0FBUyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFDckY7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLGlCQUFpQixHQUFHLENBQUMsUUFBK0IsRUFBRSxPQUFxQixFQUFnQixFQUFFO0lBQ2pHLE1BQU0sUUFBUSxHQUFhLEVBQUUsQ0FBQTtJQUM3QixNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFO1FBQzlGLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDbkIsSUFBSSxpQkFBaUIsSUFBSSxXQUFXLEVBQUU7WUFDcEMsR0FBRyxDQUFDLElBQUksQ0FBQyxtQ0FDSixpQkFBaUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQzlDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUN0QyxDQUFBO1NBQ0Y7UUFDRCxPQUFPLEdBQUcsQ0FBQTtJQUNaLENBQUMsRUFBRSxFQUFvQyxDQUFDLENBQUE7SUFFeEMscURBQ0ssa0JBQWtCLENBQUMsUUFBUSxDQUFDLEtBQy9CLElBQUksRUFBRSxRQUFRLEVBQ2QsSUFBSSxFQUFFLFFBQVEsS0FDWCxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFDaEU7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLHdCQUF3QixHQUFHLENBQUMsZUFBNkMsRUFBRSxPQUFxQixFQUF1QixFQUFFO0lBQzdILE1BQU0sVUFBVSxHQUFnQyxFQUFFLENBQUE7SUFDbEQsTUFBTSxRQUFRLEdBQWEsRUFBRSxDQUFBO0lBQzdCLE1BQU0sTUFBTSxHQUFHLGVBQWUsQ0FBQyxXQUFXLENBQUE7SUFFMUMsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNLEVBQUU7UUFDMUIsTUFBTSxZQUFZLEdBQUcsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBRTNDLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUFFO1lBQ2xDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO1NBQzFCO1FBQ0QsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsaURBQ2pCLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxHQUN6QixpQkFBaUIsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsR0FDNUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUNqRCxDQUFBO0tBQ0Y7SUFFRCxtRUFDSyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsS0FDdEMsSUFBSSxFQUFFLFFBQVEsRUFDZCxLQUFLLEVBQUUsZUFBZSxDQUFDLElBQUksS0FDeEIsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUN0QyxVQUFVLElBQ1g7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLHNCQUFzQixHQUFHLENBQUMsT0FBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxNQUFtRCxFQUFFLFNBQWlDLEVBQUUsRUFBRTtJQUNuSixJQUFJLENBQUMsQ0FBQyxhQUFhLEVBQUUsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtRQUMzRCxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLHdCQUF3QixDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQTtLQUN0RTtJQUNELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQyxDQUFBO0FBRUQsTUFBTSxlQUFlLEdBQUcsQ0FBQyxHQUE0QixFQUFFLEVBQUU7SUFDdkQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDOUMsT0FBTyxHQUFHLENBQUMsWUFBWSxDQUFBO0tBQ3hCO0lBQ0QsUUFBUSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtRQUNyQixLQUFLLEtBQUssQ0FBQztRQUNYLEtBQUssT0FBTztZQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFBO1FBRTFCLEtBQUssU0FBUztZQUNaLE9BQU8sR0FBRyxDQUFDLFlBQVksS0FBSyxNQUFNLENBQUE7S0FDckM7SUFDRCxPQUFPLEdBQUcsQ0FBQyxZQUFZLENBQUE7QUFDekIsQ0FBQyxDQUFBO0FBRUQsTUFBTSxhQUFhLEdBQUcsQ0FBQyxXQUFtRCxFQUFFLE9BQXFCLEVBQWdCLEVBQUU7SUFDakgsTUFBTSxVQUFVLEdBQWdDLEVBQUUsQ0FBQTtJQUNsRCxNQUFNLFFBQVEsR0FBYSxFQUFFLENBQUE7SUFFN0IsS0FBSyxNQUFNLEdBQUcsSUFBSSxXQUFXLEVBQUU7UUFDN0IsTUFBTSxZQUFZLEdBQUcsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBRXpDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUFFO1lBQ2hDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO1NBQ3hCO1FBQ0QsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaURBQ2YsaUJBQWlCLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQzFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUN0QixZQUFZLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUMxRCxDQUFBO0tBQ0Y7SUFFRCxxQ0FDRSxJQUFJLEVBQUUsUUFBUSxJQUNYLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FDdEMsVUFBVSxJQUNYO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsTUFBTSx3QkFBd0IsR0FBRyxDQUFDLFNBQWlDLEVBQUUsT0FBcUIsRUFBK0IsRUFBRTtJQUN6SCxpRUFDRSxLQUFLLEVBQUUsU0FBUyxDQUFDLElBQUksSUFDbEIsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQ3RFLFNBQVMsRUFBRSxDQUFFLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBRSxLQUNsQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUNoRixVQUFVLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxZQUFZLElBQ3JDO0FBQ0gsQ0FBQyxDQUFBO0FBRU0sTUFBTSxzQkFBc0IsR0FBRyxDQUFDLEVBQUUsUUFBUSxFQUFzQixFQUFFLFVBQXdCLEVBQUUsRUFBa0IsRUFBRTtJQUNySCxNQUFNLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxXQUFXLEVBQUUsS0FBSyxHQUFHLEVBQUUsRUFBRSxVQUFVLEdBQUcsRUFBRSxFQUFFLEdBQUcsUUFBUSxDQUFBO0lBRXhHLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxPQUEwQixFQUFFLEVBQUU7UUFDdEQsUUFBUSxPQUFPLENBQUMsSUFBSSxFQUFFO1lBQ3BCLEtBQUssU0FBUyxDQUFDLElBQUk7Z0JBQ2pCLE9BQU8sU0FBUyxDQUFBO1lBQ2xCLEtBQUssWUFBWSxhQUFaLFlBQVksdUJBQVosWUFBWSxDQUFFLElBQUk7Z0JBQ3JCLE9BQU8sV0FBVyxDQUFBO1lBQ3BCLEtBQUssZ0JBQWdCLGFBQWhCLGdCQUFnQix1QkFBaEIsZ0JBQWdCLENBQUUsSUFBSTtnQkFDekIsT0FBTyxlQUFlLENBQUE7U0FDekI7SUFDSCxDQUFDLENBQUE7SUFFRCxNQUFNLFdBQVcsR0FBRyxDQUFDLE1BQXNCLEVBQUUsT0FBMEIsRUFBRSxFQUFFO1FBQ3pFLFFBQVEsT0FBTyxDQUFDLElBQUksRUFBRTtZQUNwQixLQUFLLFNBQVMsQ0FBQyxJQUFJLENBQUM7WUFDcEIsS0FBSyxZQUFZLGFBQVosWUFBWSx1QkFBWixZQUFZLENBQUUsSUFBSSxDQUFDO1lBQ3hCLEtBQUssZ0JBQWdCLGFBQWhCLGdCQUFnQix1QkFBaEIsZ0JBQWdCLENBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNCLE1BQU0sR0FBRyxHQUFHLE9BQWtDLENBQUE7Z0JBQzlDLE1BQU0sSUFBSSxHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBRSxDQUFBO2dCQUN2QyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsbUJBQW1CLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQTtnQkFDdkQsTUFBSzthQUNOO1lBQ0Q7Z0JBQ0UsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFBRSxPQUFPLE1BQU0sQ0FBQTtpQkFBRTtnQkFFcEQsUUFBUSxPQUFPLENBQUMsSUFBSSxFQUFFO29CQUNwQixLQUFLLFFBQVE7d0JBQ1gsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7NEJBQ3ZFLE1BQU0sQ0FBQyxVQUFXLENBQUMsT0FBTyxtQ0FDckIsTUFBTSxDQUFDLFVBQVcsQ0FBQyxPQUFPLEtBQzdCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FDdEQsQ0FBQTt5QkFDRjt3QkFDRCxNQUFNO29CQUNSLEtBQUssUUFBUTt3QkFDWCxNQUFNLENBQUMsVUFBVyxDQUFDLE9BQU8sbUNBQ3JCLE1BQU0sQ0FBQyxVQUFXLENBQUMsT0FBTyxLQUM3QixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQ3RELENBQUE7d0JBQ0QsTUFBTTtvQkFDUixLQUFLLFdBQVc7d0JBQ2QsTUFBTSxDQUFDLFVBQVcsQ0FBQyxVQUFVLG1DQUN4QixNQUFNLENBQUMsVUFBVyxDQUFDLFVBQVUsS0FDaEMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsbUJBQW1CLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxHQUN0RCxDQUFBO3dCQUNELE1BQU07b0JBQ1IsS0FBSyxjQUFjO3dCQUNqQixNQUFNLENBQUMsVUFBVyxDQUFDLFlBQVksbUNBQzFCLE1BQU0sQ0FBQyxVQUFXLENBQUMsWUFBWSxLQUNsQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSx3QkFBd0IsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQzNELENBQUE7d0JBQ0QsTUFBTTtvQkFDUixLQUFLLE9BQU87d0JBQ1YsTUFBTSxDQUFDLFVBQVcsQ0FBQyxNQUFPLG1DQUNyQixNQUFNLENBQUMsVUFBVyxDQUFDLE1BQU0sS0FDNUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsa0JBQWtCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxHQUNyRCxDQUFBO3dCQUNELE1BQU07b0JBQ1IsS0FBSyxNQUFNO3dCQUNULE1BQU0sQ0FBQyxVQUFXLENBQUMsS0FBSyxtQ0FDbkIsTUFBTSxDQUFDLFVBQVcsQ0FBQyxLQUFLLEtBQzNCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FDcEQsQ0FBQTt3QkFDRCxNQUFNO2lCQUNUO2dCQUNELE1BQU07U0FDVDtRQUNELE9BQU8sTUFBTSxDQUFBO0lBQ2YsQ0FBQyxDQUFBO0lBRUQsT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLFdBQVcsZ0NBQzdCLFFBQVEsRUFBRSxPQUFPLElBQ2QsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQ3JDLFVBQVUsb0JBQ0wsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBRXBHLENBQUE7QUFDSixDQUFDLENBQUE7QUEvRVksUUFBQSxzQkFBc0IsMEJBK0VsQyJ9

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.printTypes = exports.typePrinter = exports.printOperations = exports.printSchema = void 0;
const utils_1 = __webpack_require__(8);
const buildinDirectives = ["specifiedBy", "deprecated", "skip", "include"];
const buildinScalars = ["Int", "Float", "Boolean", "String", "ID"];
function printSchema(graphapi) {
    return [
        printSchemaDefinition(graphapi),
        ...printTypes(graphapi.components),
        printOperations("Query", graphapi.queries),
        printOperations("Mutation", graphapi.mutations),
        printOperations("Subscription", graphapi.subscriptions),
    ]
        .filter(Boolean)
        .join('\n\n');
}
exports.printSchema = printSchema;
function printSchemaDefinition(schema) {
    const queriesCount = Object.keys(schema.queries || {}).length;
    const mutationionsCount = Object.keys(schema.mutations || {}).length;
    const subscriptionsCount = Object.keys(schema.subscriptions || {}).length;
    if (!queriesCount && !mutationionsCount && !subscriptionsCount) {
        return;
    }
    // Only print a schema definition if there is a description
    if (schema.description) {
        return (printDescription(schema.description) +
            'schema {\n' +
            (queriesCount ? `  query: Query\n` : '') +
            (mutationionsCount ? `  mutation: Mutation\n` : '') +
            (subscriptionsCount ? `  subscription: Subscription\n` : '') +
            '}');
    }
}
function printOperations(name, operations) {
    if (!operations) {
        return "";
    }
    return printObject(name, { title: name, type: "object", properties: operations, required: Object.keys(operations) });
}
exports.printOperations = printOperations;
function typePrinter(componentKind) {
    switch (componentKind) {
        case "directives": return printDirective;
        case "scalars": return printScalar;
        case "objects": return printObject;
        case "interfaces": return printInterface;
        case "unions": return printUnion;
        case "enums": return printEnum;
        case "inputObjects": return printInputObject;
    }
}
exports.typePrinter = typePrinter;
function printTypes(components = {}) {
    const types = [];
    const kinds = ["directives", "scalars", "objects", "interfaces", "unions", "enums", "inputObjects"];
    for (const kind of kinds) {
        const printer = typePrinter(kind);
        const definitions = components[kind];
        if (!definitions) {
            continue;
        }
        for (const [name, definition] of Object.entries(definitions)) {
            types.push(printer(name, definition));
        }
    }
    return types;
}
exports.printTypes = printTypes;
function printScalar(name, type) {
    var _a;
    if (buildinScalars.includes(name)) {
        return "";
    }
    return (printDescription(type.description) +
        `scalar ${name}` +
        printSpecifiedByURL((_a = type.directives) === null || _a === void 0 ? void 0 : _a.specifiedBy));
}
function printImplementedInterfaces(interfaces = []) {
    return interfaces.length
        ? ' implements ' + interfaces.map(typeName).join(' & ')
        : '';
}
function printObject(name, type) {
    return (printDescription(type.description) +
        `type ${name}` +
        printImplementedInterfaces(type.interfaces) +
        printFields(type, type.required));
}
function printInterface(name, type) {
    return (printDescription(type.description) +
        `interface ${name}` +
        printImplementedInterfaces(type.interfaces) +
        printFields(type, type.required));
}
function printUnion(name, type) {
    const types = type.oneOf.map((item) => typeName(item));
    const possibleTypes = types.length ? ' = ' + types.join(' | ') : '';
    return printDescription(type.description) + 'union ' + name + possibleTypes;
}
function typeName(type) {
    return type.$ref ? type.$ref.split("/").pop() : type.title;
}
function printEnum(name, type) {
    const values = type.enum.map((name, i) => {
        var _a, _b;
        const value = (_b = (_a = type.values) === null || _a === void 0 ? void 0 : _a[name]) !== null && _b !== void 0 ? _b : {};
        return printDescription(value.description, '  ', !i) +
            '  ' +
            name +
            printDirectives({}, value.deprecated);
    });
    return printDescription(type.description) + `enum ${name}` + printBlock(values);
}
function printInputObject(name, type) {
    const fieldList = Object.entries(type.properties || {});
    const fields = fieldList.map(([name, field], i) => { var _a; return printDescription(field.description, '  ', !i) + '  ' + printInputValue(name, field, (_a = type.required) === null || _a === void 0 ? void 0 : _a.includes(name)); });
    return printDescription(type.description) + `input ${name}` + printBlock(fields);
}
function printFields(type, required = []) {
    const fieldList = Object.entries(type.properties || {});
    const fields = fieldList.map(([name, field], i) => printDescription(field.description, '  ', !i) +
        '  ' +
        name +
        printArgs(field.args, '  ') +
        ': ' +
        printTypeRef(field, !required.includes(name)) +
        printDirectives(field.directives, field.deprecated));
    return printBlock(fields);
}
function printBlock(items) {
    return items.length !== 0 ? ' {\n' + items.join('\n') + '\n}' : '';
}
function printArgs(args, indentation = '') {
    var _a;
    if (!args) {
        return "";
    }
    const argList = Object.entries((_a = args.properties) !== null && _a !== void 0 ? _a : {});
    if (argList.length === 0) {
        return '';
    }
    // If every arg does not have a description, print them on one line.
    if (argList.every(([, arg]) => !arg.description)) {
        return '(' + argList.map(([name, arg]) => { var _a; return printInputValue(name, arg, (_a = args.required) === null || _a === void 0 ? void 0 : _a.includes(name)); }).join(', ') + ')';
    }
    return ('(\n' + argList.map(([name, arg], i) => {
        var _a;
        return printDescription(arg.description, '  ' + indentation, !i) +
            '  ' +
            indentation +
            printInputValue(name, arg, (_a = args.required) === null || _a === void 0 ? void 0 : _a.includes(name));
    }).join('\n') + '\n' + indentation + ')');
}
function printTypeRef(schema, nullable = false) {
    if (!schema) {
        return "";
    }
    const { $ref, oneOf, type } = schema;
    const postfix = (nullable || schema.nullable) ? "" : "!";
    if ($ref) {
        return $ref.split("/").pop() + postfix;
    }
    else if (type === "array") {
        return `[${printTypeRef(schema.items)}]${postfix}`;
    }
    else if (type && ['string', 'number', 'integer', 'boolean'].includes(type)) {
        if (schema.format) {
            return schema.format + postfix;
        }
        else {
            switch (type) {
                case 'string': return 'String' + postfix;
                case 'number': return 'Float' + postfix;
                case 'integer': return 'Int' + postfix;
                case 'boolean': return 'Boolean' + postfix;
            }
        }
    }
    else if (oneOf && oneOf.length === 2) {
        const nullIndex = oneOf.findIndex((item) => item.type === "null");
        if (nullIndex < 0) {
            throw new Error(`Expected null type in 'oneOf' item not found: ${schema.title}`);
        }
        return printTypeRef(nullIndex ? oneOf[0] : oneOf[1]);
    }
    throw new Error(`Unexpected type: ${schema.title}`);
}
function printArgValue(value) {
    return typeof value === "string" ? (0, utils_1.printString)(value) : String(value);
}
function printDirectiveArgs(args = {}) {
    const argList = Object.entries(args);
    if (!argList.length) {
        return "";
    }
    return '(' + argList.map(([name, value]) => `${name}: ${printArgValue(value)}`).join(', ') + ')';
}
function printDirectives(directives, deprecated) {
    if (!directives && !deprecated) {
        return '';
    }
    let result = "";
    const _directives = Object.assign(Object.assign({}, directives), deprecated ? { deprecated: { $ref: "", meta: typeof deprecated === 'boolean' ? {} : deprecated } } : {});
    for (const [name, directive] of Object.entries(_directives)) {
        result += ` @${name}${printDirectiveArgs(directive.meta)}`;
    }
    return result;
}
function printInputValue(name, arg, required = false) {
    const type = printTypeRef(arg, !required);
    return (name + ': ' + type +
        (arg.default !== undefined ? ` = ${String(arg.default)}` : "") +
        printDirectives(arg.directives, arg.deprecated));
}
function printDirective(name, directive) {
    if (buildinDirectives.includes(name)) {
        return "";
    }
    return (printDescription(directive.description) +
        'directive @' +
        name +
        printArgs(directive.args) +
        (directive.repeatable ? ' repeatable' : '') +
        ' on ' +
        directive.locations.join(' | '));
}
function printSpecifiedByURL(directive) {
    var _a;
    return !directive || !((_a = directive.meta) === null || _a === void 0 ? void 0 : _a.url) ? "" : ` @specifiedBy(url: ${(0, utils_1.printString)(directive.meta.url)})`;
}
function printDescription(value, indent = '', firstInBlock = true) {
    if (!value) {
        return '';
    }
    const blockString = (0, utils_1.isPrintableAsBlockString)(value) ? (0, utils_1.printBlockString)(value) : (0, utils_1.printString)(value);
    const prefix = indent && !firstInBlock ? '\n' + indent : indent;
    return prefix + blockString.replaceAll('\n', '\n' + indent) + '\n';
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpbnRTY2hlbWEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvcHJpbnRTY2hlbWEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsbUNBQXdGO0FBU3hGLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxhQUFhLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQTtBQUMxRSxNQUFNLGNBQWMsR0FBRyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQTtBQUVsRSxTQUFnQixXQUFXLENBQUMsUUFBd0I7SUFDbEQsT0FBTztRQUNMLHFCQUFxQixDQUFDLFFBQVEsQ0FBQztRQUMvQixHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDO1FBQ2xDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQztRQUMxQyxlQUFlLENBQUMsVUFBVSxFQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUM7UUFDOUMsZUFBZSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsYUFBYSxDQUFDO0tBQ3hEO1NBQ0EsTUFBTSxDQUFDLE9BQU8sQ0FBQztTQUNmLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUNmLENBQUM7QUFWRCxrQ0FVQztBQUVELFNBQVMscUJBQXFCLENBQUMsTUFBc0I7SUFDbkQsTUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQTtJQUM3RCxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUE7SUFDcEUsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFBO0lBRXpFLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQyxpQkFBaUIsSUFBSSxDQUFDLGtCQUFrQixFQUFFO1FBQzlELE9BQU07S0FDUDtJQUVELDJEQUEyRDtJQUMzRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEVBQUU7UUFDdEIsT0FBTyxDQUNMLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7WUFDcEMsWUFBWTtZQUNaLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ3hDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDbkQsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsZ0NBQWdDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUM1RCxHQUFHLENBQ0osQ0FBQTtLQUNGO0FBQ0gsQ0FBQztBQUlELFNBQWdCLGVBQWUsQ0FBQyxJQUFZLEVBQUUsVUFBd0M7SUFDcEYsSUFBSSxDQUFDLFVBQVUsRUFBRTtRQUFFLE9BQU8sRUFBRSxDQUFBO0tBQUU7SUFDOUIsT0FBTyxXQUFXLENBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3RILENBQUM7QUFIRCwwQ0FHQztBQUVELFNBQWdCLFdBQVcsQ0FBQyxhQUFxQztJQUMvRCxRQUFRLGFBQWEsRUFBRTtRQUNyQixLQUFLLFlBQVksQ0FBQyxDQUFDLE9BQU8sY0FBYyxDQUFBO1FBQ3hDLEtBQUssU0FBUyxDQUFDLENBQUMsT0FBTyxXQUFXLENBQUE7UUFDbEMsS0FBSyxTQUFTLENBQUMsQ0FBQyxPQUFPLFdBQVcsQ0FBQTtRQUNsQyxLQUFLLFlBQVksQ0FBQyxDQUFDLE9BQU8sY0FBYyxDQUFBO1FBQ3hDLEtBQUssUUFBUSxDQUFDLENBQUMsT0FBTyxVQUFVLENBQUE7UUFDaEMsS0FBSyxPQUFPLENBQUMsQ0FBQyxPQUFPLFNBQVMsQ0FBQTtRQUM5QixLQUFLLGNBQWMsQ0FBQyxDQUFDLE9BQU8sZ0JBQWdCLENBQUE7S0FDN0M7QUFDSCxDQUFDO0FBVkQsa0NBVUM7QUFFRCxTQUFnQixVQUFVLENBQUMsYUFBaUMsRUFBRTtJQUM1RCxNQUFNLEtBQUssR0FBYSxFQUFFLENBQUE7SUFDMUIsTUFBTSxLQUFLLEdBQTZCLENBQUMsWUFBWSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsY0FBYyxDQUFDLENBQUE7SUFFN0gsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUU7UUFDeEIsTUFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBRSxDQUFBO1FBQ2xDLE1BQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUVwQyxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQUUsU0FBUTtTQUFFO1FBRTlCLEtBQUssTUFBTSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQzVELEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFBO1NBQ3RDO0tBQ0Y7SUFFRCxPQUFPLEtBQUssQ0FBQTtBQUNkLENBQUM7QUFoQkQsZ0NBZ0JDO0FBRUQsU0FBUyxXQUFXLENBQUMsSUFBWSxFQUFFLElBQW9COztJQUNyRCxJQUFJLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFBRSxPQUFPLEVBQUUsQ0FBQTtLQUFFO0lBRWhELE9BQU8sQ0FDTCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQ2xDLFVBQVUsSUFBSSxFQUFFO1FBQ2hCLG1CQUFtQixDQUFDLE1BQUEsSUFBSSxDQUFDLFVBQVUsMENBQUUsV0FBVyxDQUFDLENBQ2xELENBQUE7QUFDSCxDQUFDO0FBRUQsU0FBUywwQkFBMEIsQ0FBQyxhQUFpQyxFQUFFO0lBQ3JFLE9BQU8sVUFBVSxDQUFDLE1BQU07UUFDdEIsQ0FBQyxDQUFDLGNBQWMsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtBQUNSLENBQUM7QUFFRCxTQUFTLFdBQVcsQ0FBQyxJQUFZLEVBQUUsSUFBb0I7SUFDckQsT0FBTyxDQUNMLGdCQUFnQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDbEMsUUFBUSxJQUFJLEVBQUU7UUFDZCwwQkFBMEIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQzNDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUNqQyxDQUFBO0FBQ0gsQ0FBQztBQUVELFNBQVMsY0FBYyxDQUFDLElBQVksRUFBRSxJQUF1QjtJQUMzRCxPQUFPLENBQ0wsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUNsQyxhQUFhLElBQUksRUFBRTtRQUNuQiwwQkFBMEIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQzNDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUNqQyxDQUFBO0FBQ0gsQ0FBQztBQUVELFNBQVMsVUFBVSxDQUFDLElBQVksRUFBRSxJQUFtQjtJQUNuRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7SUFDdEQsTUFBTSxhQUFhLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtJQUNuRSxPQUFPLGdCQUFnQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxRQUFRLEdBQUcsSUFBSSxHQUFHLGFBQWEsQ0FBQTtBQUM3RSxDQUFDO0FBRUQsU0FBUyxRQUFRLENBQUMsSUFBaUI7SUFDakMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQTtBQUM1RCxDQUFDO0FBRUQsU0FBUyxTQUFTLENBQUMsSUFBWSxFQUFFLElBQWtCO0lBQ2pELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFOztRQUN4QyxNQUFNLEtBQUssR0FBRyxNQUFBLE1BQUEsSUFBSSxDQUFDLE1BQU0sMENBQUcsSUFBSSxDQUFDLG1DQUFJLEVBQUUsQ0FBQTtRQUN2QyxPQUFPLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ2xELElBQUk7WUFDSixJQUFJO1lBQ0osZUFBZSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUE7SUFDekMsQ0FBQyxDQUFDLENBQUE7SUFFRixPQUFPLGdCQUFnQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxRQUFRLElBQUksRUFBRSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUNqRixDQUFDO0FBRUQsU0FBUyxnQkFBZ0IsQ0FBQyxJQUFZLEVBQUUsSUFBeUI7SUFDL0QsTUFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0lBQ3ZELE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxXQUFDLE9BQUEsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLEdBQUcsZUFBZSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBQSxJQUFJLENBQUMsUUFBUSwwQ0FBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQSxFQUFBLENBQUMsQ0FBQTtJQUN0SyxPQUFPLGdCQUFnQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLElBQUksRUFBRSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUNsRixDQUFDO0FBRUQsU0FBUyxXQUFXLENBQUMsSUFBd0MsRUFBRSxXQUFxQixFQUFFO0lBQ3BGLE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsQ0FBQTtJQUV2RCxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FDaEQsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDN0MsSUFBSTtRQUNKLElBQUk7UUFDSixTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7UUFDM0IsSUFBSTtRQUNKLFlBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzdDLGVBQWUsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FDcEQsQ0FBQTtJQUNELE9BQU8sVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQzNCLENBQUM7QUFFRCxTQUFTLFVBQVUsQ0FBQyxLQUE0QjtJQUM5QyxPQUFPLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtBQUNwRSxDQUFDO0FBRUQsU0FBUyxTQUFTLENBQUMsSUFBa0IsRUFBRSxXQUFXLEdBQUcsRUFBRTs7SUFDckQsSUFBSSxDQUFDLElBQUksRUFBRTtRQUFFLE9BQU8sRUFBRSxDQUFBO0tBQUU7SUFFeEIsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFBLElBQUksQ0FBQyxVQUFVLG1DQUFJLEVBQUUsQ0FBQyxDQUFBO0lBRXJELElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFBRSxPQUFPLEVBQUUsQ0FBQTtLQUFFO0lBRXZDLG9FQUFvRTtJQUNwRSxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1FBQy9DLE9BQU8sR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsRUFBRSxFQUFFLFdBQUMsT0FBQSxlQUFlLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxNQUFBLElBQUksQ0FBQyxRQUFRLDBDQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBLEVBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUE7S0FDdEg7SUFFRCxPQUFPLENBQ0wsS0FBSyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTs7UUFDckMsT0FBQSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLElBQUksR0FBRyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDekQsSUFBSTtZQUNKLFdBQVc7WUFDWCxlQUFlLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxNQUFBLElBQUksQ0FBQyxRQUFRLDBDQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO0tBQUEsQ0FDMUQsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLFdBQVcsR0FBRyxHQUFHLENBQ3hDLENBQUE7QUFDSCxDQUFDO0FBRUQsU0FBUyxZQUFZLENBQUUsTUFBb0IsRUFBRSxRQUFRLEdBQUcsS0FBSztJQUMzRCxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQUUsT0FBTyxFQUFFLENBQUE7S0FBRTtJQUMxQixNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxNQUFNLENBQUE7SUFDcEMsTUFBTSxPQUFPLEdBQUcsQ0FBQyxRQUFRLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQTtJQUN4RCxJQUFJLElBQUksRUFBRTtRQUNSLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxPQUFPLENBQUE7S0FDdkM7U0FBTSxJQUFJLElBQUksS0FBSyxPQUFPLEVBQUU7UUFDM0IsT0FBTyxJQUFJLFlBQVksQ0FBRSxNQUF1QixDQUFDLEtBQUssQ0FBQyxJQUFJLE9BQU8sRUFBRSxDQUFBO0tBQ3JFO1NBQU0sSUFBSSxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDNUUsSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFO1lBQ2pCLE9BQU8sTUFBTSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUE7U0FDL0I7YUFBTTtZQUNMLFFBQVEsSUFBSSxFQUFFO2dCQUNaLEtBQUssUUFBUSxDQUFDLENBQUMsT0FBTyxRQUFRLEdBQUcsT0FBTyxDQUFBO2dCQUN4QyxLQUFLLFFBQVEsQ0FBQyxDQUFDLE9BQU8sT0FBTyxHQUFHLE9BQU8sQ0FBQTtnQkFDdkMsS0FBSyxTQUFTLENBQUMsQ0FBQyxPQUFPLEtBQUssR0FBRyxPQUFPLENBQUE7Z0JBQ3RDLEtBQUssU0FBUyxDQUFDLENBQUMsT0FBTyxTQUFTLEdBQUcsT0FBTyxDQUFBO2FBQzNDO1NBQ0Y7S0FDRjtTQUFNLElBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQ3RDLE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUE7UUFDakUsSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFO1lBQ2pCLE1BQU0sSUFBSSxLQUFLLENBQUMsaURBQWlELE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFBO1NBQ2pGO1FBQ0QsT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0tBQ3JEO0lBQ0QsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7QUFDckQsQ0FBQztBQUVELFNBQVMsYUFBYSxDQUFDLEtBQVU7SUFDL0IsT0FBTyxPQUFPLEtBQUssS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUEsbUJBQVcsRUFBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ3ZFLENBQUM7QUFFRCxTQUFTLGtCQUFrQixDQUFDLE9BQTRCLEVBQUU7SUFDeEQsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUNwQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtRQUFFLE9BQU8sRUFBRSxDQUFBO0tBQUU7SUFDbEMsT0FBTyxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLElBQUksS0FBSyxhQUFhLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUE7QUFDbEcsQ0FBQztBQUVELFNBQVMsZUFBZSxDQUFDLFVBQThDLEVBQUUsVUFBeUM7SUFDaEgsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLFVBQVUsRUFBRTtRQUFFLE9BQU8sRUFBRSxDQUFBO0tBQUU7SUFDN0MsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFBO0lBQ2YsTUFBTSxXQUFXLG1DQUNaLFVBQVUsR0FDVixVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsT0FBTyxVQUFVLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FDM0csQ0FBQTtJQUNELEtBQUssTUFBTSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1FBQzNELE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQTtLQUMzRDtJQUNELE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQztBQUVELFNBQVMsZUFBZSxDQUFDLElBQVksRUFBRSxHQUFnQixFQUFFLFFBQVEsR0FBRyxLQUFLO0lBQ3ZFLE1BQU0sSUFBSSxHQUFHLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUN6QyxPQUFPLENBQ0wsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJO1FBQ2xCLENBQUMsR0FBRyxDQUFDLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDOUQsZUFBZSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUNoRCxDQUFBO0FBQ0gsQ0FBQztBQUVELFNBQVMsY0FBYyxDQUFDLElBQVksRUFBRSxTQUFzQztJQUMxRSxJQUFJLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtRQUFFLE9BQU8sRUFBRSxDQUFBO0tBQUU7SUFFbkQsT0FBTyxDQUNMLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUM7UUFDdkMsYUFBYTtRQUNiLElBQUk7UUFDSixTQUFTLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztRQUN6QixDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzNDLE1BQU07UUFDTixTQUFTLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FDaEMsQ0FBQTtBQUNILENBQUM7QUFFRCxTQUFTLG1CQUFtQixDQUFDLFNBQTZCOztJQUN4RCxPQUFPLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQSxNQUFBLFNBQVMsQ0FBQyxJQUFJLDBDQUFFLEdBQUcsQ0FBQSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixJQUFBLG1CQUFXLEVBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFBO0FBQzNHLENBQUM7QUFFRCxTQUFTLGdCQUFnQixDQUFDLEtBQWMsRUFBRSxNQUFNLEdBQUcsRUFBRSxFQUFFLFlBQVksR0FBRyxJQUFJO0lBQ3hFLElBQUksQ0FBQyxLQUFLLEVBQUU7UUFBRSxPQUFPLEVBQUUsQ0FBQTtLQUFFO0lBRXpCLE1BQU0sV0FBVyxHQUFHLElBQUEsZ0NBQXdCLEVBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUEsd0JBQWdCLEVBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUEsbUJBQVcsRUFBQyxLQUFLLENBQUMsQ0FBQTtJQUVsRyxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQTtJQUUvRCxPQUFPLE1BQU0sR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFBO0FBQ3BFLENBQUMifQ==

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.printBlockString = exports.printString = exports.isWhiteSpace = exports.isPrintableAsBlockString = exports.mapRecord = void 0;
const mapRecord = (record, iterator) => {
    return Object.fromEntries(Object.entries(record).map(([key, item]) => [key, iterator(item, key, record)]));
};
exports.mapRecord = mapRecord;
// graphql-js internal function
function isPrintableAsBlockString(value) {
    if (value === '') {
        return true; // empty string is printable
    }
    let isEmptyLine = true;
    let hasIndent = false;
    let hasCommonIndent = true;
    let seenNonEmptyLine = false;
    for (let i = 0; i < value.length; ++i) {
        switch (value.codePointAt(i)) {
            case 0x0000:
            case 0x0001:
            case 0x0002:
            case 0x0003:
            case 0x0004:
            case 0x0005:
            case 0x0006:
            case 0x0007:
            case 0x0008:
            case 0x000b:
            case 0x000c:
            case 0x000e:
            case 0x000f:
                return false; // Has non-printable characters
            case 0x000d: //  \r
                return false; // Has \r or \r\n which will be replaced as \n
            case 10: //  \n
                if (isEmptyLine && !seenNonEmptyLine) {
                    return false; // Has leading new line
                }
                seenNonEmptyLine = true;
                isEmptyLine = true;
                hasIndent = false;
                break;
            case 9: //   \t
            case 32: //  <space>
                hasIndent || (hasIndent = isEmptyLine);
                break;
            default:
                hasCommonIndent && (hasCommonIndent = hasIndent);
                isEmptyLine = false;
        }
    }
    if (isEmptyLine) {
        return false; // Has trailing empty lines
    }
    if (hasCommonIndent && seenNonEmptyLine) {
        return false; // Has internal indent
    }
    return true;
}
exports.isPrintableAsBlockString = isPrintableAsBlockString;
/**
 * ```
 * WhiteSpace ::
 *   - "Horizontal Tab (U+0009)"
 *   - "Space (U+0020)"
 * ```
 * @internal
 */
function isWhiteSpace(code) {
    return code === 0x0009 || code === 0x0020;
}
exports.isWhiteSpace = isWhiteSpace;
// eslint-disable-next-line no-control-regex
const escapedRegExp = /[\x00-\x1f\x22\x5c\x7f-\x9f]/g;
function escapedReplacer(str) {
    return escapeSequences[str.charCodeAt(0)];
}
// prettier-ignore
const escapeSequences = [
    '\\u0000', '\\u0001', '\\u0002', '\\u0003', '\\u0004', '\\u0005', '\\u0006', '\\u0007',
    '\\b', '\\t', '\\n', '\\u000B', '\\f', '\\r', '\\u000E', '\\u000F',
    '\\u0010', '\\u0011', '\\u0012', '\\u0013', '\\u0014', '\\u0015', '\\u0016', '\\u0017',
    '\\u0018', '\\u0019', '\\u001A', '\\u001B', '\\u001C', '\\u001D', '\\u001E', '\\u001F',
    '', '', '\\"', '', '', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '\\\\', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '\\u007F',
    '\\u0080', '\\u0081', '\\u0082', '\\u0083', '\\u0084', '\\u0085', '\\u0086', '\\u0087',
    '\\u0088', '\\u0089', '\\u008A', '\\u008B', '\\u008C', '\\u008D', '\\u008E', '\\u008F',
    '\\u0090', '\\u0091', '\\u0092', '\\u0093', '\\u0094', '\\u0095', '\\u0096', '\\u0097',
    '\\u0098', '\\u0099', '\\u009A', '\\u009B', '\\u009C', '\\u009D', '\\u009E', '\\u009F',
];
function printString(str) {
    return `"${str.replace(escapedRegExp, escapedReplacer)}"`;
}
exports.printString = printString;
/**
 * Print a block string in the indented block form by adding a leading and
 * trailing blank line. However, if a block string starts with whitespace and is
 * a single-line, adding a leading blank line would strip that whitespace.
 *
 * graphql-js internal function
 */
function printBlockString(value, options) {
    const escapedValue = value.replaceAll('"""', '\\"""');
    // Expand a block string's raw value into independent lines.
    const lines = escapedValue.split(/\r\n|[\n\r]/g);
    const isSingleLine = lines.length === 1;
    // If common indentation is found we can fix some of those cases by adding leading new line
    const forceLeadingNewLine = lines.length > 1 &&
        lines
            .slice(1)
            .every((line) => line.length === 0 || isWhiteSpace(line.charCodeAt(0)));
    // Trailing triple quotes just looks confusing but doesn't force trailing new line
    const hasTrailingTripleQuotes = escapedValue.endsWith('\\"""');
    // Trailing quote (single or double) or slash forces trailing new line
    const hasTrailingQuote = value.endsWith('"') && !hasTrailingTripleQuotes;
    const hasTrailingSlash = value.endsWith('\\');
    const forceTrailingNewline = hasTrailingQuote || hasTrailingSlash;
    const printAsMultipleLines = !(options === null || options === void 0 ? void 0 : options.minimize) &&
        // add leading and trailing new lines only if it improves readability
        (!isSingleLine ||
            value.length > 70 ||
            forceTrailingNewline ||
            forceLeadingNewLine ||
            hasTrailingTripleQuotes);
    let result = '';
    // Format a multi-line block quote to account for leading space.
    const skipLeadingNewLine = isSingleLine && isWhiteSpace(value.charCodeAt(0));
    if ((printAsMultipleLines && !skipLeadingNewLine) || forceLeadingNewLine) {
        result += '\n';
    }
    result += escapedValue;
    if (printAsMultipleLines || forceTrailingNewline) {
        result += '\n';
    }
    return '"""' + result + '"""';
}
exports.printBlockString = printBlockString;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdXRpbHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRU8sTUFBTSxTQUFTLEdBQUcsQ0FBTyxNQUF5QixFQUFFLFFBQWdFLEVBQUcsRUFBRTtJQUM5SCxPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDNUcsQ0FBQyxDQUFBO0FBRlksUUFBQSxTQUFTLGFBRXJCO0FBRUQsK0JBQStCO0FBRS9CLFNBQWdCLHdCQUF3QixDQUFDLEtBQWE7SUFDcEQsSUFBSSxLQUFLLEtBQUssRUFBRSxFQUFFO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLENBQUMsNEJBQTRCO0tBQzFDO0lBRUQsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDO0lBQ3ZCLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQztJQUN0QixJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUM7SUFDM0IsSUFBSSxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7SUFFN0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7UUFDckMsUUFBUSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQzVCLEtBQUssTUFBTSxDQUFDO1lBQ1osS0FBSyxNQUFNLENBQUM7WUFDWixLQUFLLE1BQU0sQ0FBQztZQUNaLEtBQUssTUFBTSxDQUFDO1lBQ1osS0FBSyxNQUFNLENBQUM7WUFDWixLQUFLLE1BQU0sQ0FBQztZQUNaLEtBQUssTUFBTSxDQUFDO1lBQ1osS0FBSyxNQUFNLENBQUM7WUFDWixLQUFLLE1BQU0sQ0FBQztZQUNaLEtBQUssTUFBTSxDQUFDO1lBQ1osS0FBSyxNQUFNLENBQUM7WUFDWixLQUFLLE1BQU0sQ0FBQztZQUNaLEtBQUssTUFBTTtnQkFDVCxPQUFPLEtBQUssQ0FBQyxDQUFDLCtCQUErQjtZQUUvQyxLQUFLLE1BQU0sRUFBRSxNQUFNO2dCQUNqQixPQUFPLEtBQUssQ0FBQyxDQUFDLDhDQUE4QztZQUU5RCxLQUFLLEVBQUUsRUFBRSxNQUFNO2dCQUNiLElBQUksV0FBVyxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7b0JBQ3BDLE9BQU8sS0FBSyxDQUFDLENBQUMsdUJBQXVCO2lCQUN0QztnQkFDRCxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7Z0JBRXhCLFdBQVcsR0FBRyxJQUFJLENBQUM7Z0JBQ25CLFNBQVMsR0FBRyxLQUFLLENBQUM7Z0JBQ2xCLE1BQU07WUFDUixLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU87WUFDZixLQUFLLEVBQUUsRUFBRSxXQUFXO2dCQUNsQixTQUFTLEtBQVQsU0FBUyxHQUFLLFdBQVcsRUFBQztnQkFDMUIsTUFBTTtZQUNSO2dCQUNFLGVBQWUsS0FBZixlQUFlLEdBQUssU0FBUyxFQUFDO2dCQUM5QixXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQ3ZCO0tBQ0Y7SUFFRCxJQUFJLFdBQVcsRUFBRTtRQUNmLE9BQU8sS0FBSyxDQUFDLENBQUMsMkJBQTJCO0tBQzFDO0lBRUQsSUFBSSxlQUFlLElBQUksZ0JBQWdCLEVBQUU7UUFDdkMsT0FBTyxLQUFLLENBQUMsQ0FBQyxzQkFBc0I7S0FDckM7SUFFRCxPQUFPLElBQUksQ0FBQztBQUNkLENBQUM7QUExREQsNERBMERDO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILFNBQWdCLFlBQVksQ0FBQyxJQUFZO0lBQ3ZDLE9BQU8sSUFBSSxLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUssTUFBTSxDQUFDO0FBQzVDLENBQUM7QUFGRCxvQ0FFQztBQUVELDRDQUE0QztBQUM1QyxNQUFNLGFBQWEsR0FBRywrQkFBK0IsQ0FBQztBQUV0RCxTQUFTLGVBQWUsQ0FBQyxHQUFXO0lBQ2xDLE9BQU8sZUFBZSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDO0FBRUQsa0JBQWtCO0FBQ2xCLE1BQU0sZUFBZSxHQUFHO0lBQ3RCLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO0lBQ3RGLEtBQUssRUFBTSxLQUFLLEVBQU0sS0FBSyxFQUFNLFNBQVMsRUFBRSxLQUFLLEVBQU0sS0FBSyxFQUFNLFNBQVMsRUFBRSxTQUFTO0lBQ3RGLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO0lBQ3RGLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO0lBQ3RGLEVBQUUsRUFBUyxFQUFFLEVBQVMsS0FBSyxFQUFNLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxNQUFNLEVBQUssRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFO0lBQy9FLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxFQUFFLEVBQVMsRUFBRSxFQUFTLEVBQUUsRUFBUyxTQUFTO0lBQ3RGLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO0lBQ3RGLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO0lBQ3RGLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO0lBQ3RGLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO0NBQ3ZGLENBQUM7QUFFRixTQUFnQixXQUFXLENBQUMsR0FBVztJQUNyQyxPQUFPLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsZUFBZSxDQUFDLEdBQUcsQ0FBQztBQUM1RCxDQUFDO0FBRkQsa0NBRUM7QUFFRDs7Ozs7O0dBTUc7QUFDSCxTQUFnQixnQkFBZ0IsQ0FDOUIsS0FBYSxFQUNiLE9BQWdDO0lBRWhDLE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBRXRELDREQUE0RDtJQUM1RCxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ2pELE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO0lBRXhDLDJGQUEyRjtJQUMzRixNQUFNLG1CQUFtQixHQUN2QixLQUFLLENBQUMsTUFBTSxHQUFHLENBQUM7UUFDaEIsS0FBSzthQUNGLEtBQUssQ0FBQyxDQUFDLENBQUM7YUFDUixLQUFLLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUU1RSxrRkFBa0Y7SUFDbEYsTUFBTSx1QkFBdUIsR0FBRyxZQUFZLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBRS9ELHNFQUFzRTtJQUN0RSxNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN6RSxNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUMsTUFBTSxvQkFBb0IsR0FBRyxnQkFBZ0IsSUFBSSxnQkFBZ0IsQ0FBQztJQUVsRSxNQUFNLG9CQUFvQixHQUN4QixDQUFDLENBQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLFFBQVEsQ0FBQTtRQUNsQixxRUFBcUU7UUFDckUsQ0FBQyxDQUFDLFlBQVk7WUFDWixLQUFLLENBQUMsTUFBTSxHQUFHLEVBQUU7WUFDakIsb0JBQW9CO1lBQ3BCLG1CQUFtQjtZQUNuQix1QkFBdUIsQ0FBQyxDQUFDO0lBRTdCLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztJQUVoQixnRUFBZ0U7SUFDaEUsTUFBTSxrQkFBa0IsR0FBRyxZQUFZLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM3RSxJQUFJLENBQUMsb0JBQW9CLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLG1CQUFtQixFQUFFO1FBQ3hFLE1BQU0sSUFBSSxJQUFJLENBQUM7S0FDaEI7SUFFRCxNQUFNLElBQUksWUFBWSxDQUFDO0lBQ3ZCLElBQUksb0JBQW9CLElBQUksb0JBQW9CLEVBQUU7UUFDaEQsTUFBTSxJQUFJLElBQUksQ0FBQztLQUNoQjtJQUVELE9BQU8sS0FBSyxHQUFHLE1BQU0sR0FBRyxLQUFLLENBQUM7QUFDaEMsQ0FBQztBQWhERCw0Q0FnREMifQ==

/***/ })
/******/ ]);